import React from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";
import { TextField, Button, Box, Stack, Typography, Link } from "@mui/material";

const Login = () => {
  const navigate = useNavigate();
  const formik = useFormik({
    initialValues: {
      username: "",
      password: "",
    },
    validationSchema: Yup.object({
      username: Yup.string()
        .oneOf(["Admin"], "Username must be 'Admin'")
        .required("Username is required"),
      password: Yup.string()
        .oneOf(["Admin"], "Password must be 'Admin'")
        .required("Password is required"),
    }),

    onSubmit: (values) => {
      console.log("Form submitted with values:", values);
      // Handle login logic here (e.g., authentication)
      navigate("/dashboard");
    },
  });

  return (
    <div
      className=" min-h-screen bg-gray-100"
      style={{
        backgroundImage: "url('/bg_image.jpg')",
        backgroundSize: "100% 100%", // Ensures the image stretches to cover both width and height
        backgroundPosition: "center", // Centers the image within the container
        backgroundRepeat: "no-repeat", // Prevents tiling
        width: "100vw", // Full viewport width
        height: "100vh", // Full viewport height
      }}
    >
      <div
        style={{
          position: "absolute",
          width: "500px",
          height: "15px",
          marginLeft: "30px",
          marginTop: "25px",
        }}
      >
        <img src="/Titile.png"></img>
      </div>
      <div
        className="bg-white p-8 rounded-lg shadow-lg w-96 mr-5"
        style={{
          position: "absolute",
          right: "30px",
          width: "375px",
          height: "500px",
          border: "2px solid #5345FD",
          borderRadius: "30px",
          top: "25px",
        }}
      >
        <div>
          <h2 className="text-3xl font-semibold text-center mb-6 text-gray-800">
            Sign In
          </h2>

          <Box
            component="form"
            onSubmit={formik.handleSubmit}
            sx={{ maxWidth: 400, mx: "auto" }}
          >
            {/* Username Input */}
            <TextField
              fullWidth
              margin="normal"
              id="username"
              name="username"
              label="Enter Username"
              value={formik.values.username}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              error={formik.touched.username && Boolean(formik.errors.username)}
              helperText={formik.touched.username && formik.errors.username}
            />

            {/* Password Input */}
            <TextField
              fullWidth
              margin="normal"
              type="password"
              id="password"
              name="password"
              label="Password"
              value={formik.values.password}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              error={formik.touched.password && Boolean(formik.errors.password)}
              helperText={formik.touched.password && formik.errors.password}
              sx={{ mb: 0 }}
            />
            <div className="text-right">
              <a
                href="#"
                className="text-sm text-blue-500 hover:text-blue-700"
                style={{ color: "#2567ae" }}
              >
                Forgot your password?
              </a>
            </div>
            {/* Login Button */}
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{
                mt: 2,
                bgcolor: "#0225AA",
                ":hover": { bgcolor: "#021a80" },
              }}
            >
              Login
            </Button>
            <Stack
              direction="row"
              justifyContent="center"
              alignItems="center"
              spacing={1}
              sx={{ mt: 2 }}
            >
              <Typography variant="body2" color="textSecondary">
                Create an account
              </Typography>
              <Link
                
                variant="body2"
                sx={{ fontWeight: "bold", textDecoration: "none" }}
              >
                SignUp
              </Link>
            </Stack>
            <Typography
              variant="body2"
              color="textSecondary"
              sx={{ mt: 12, textAlign: "center" }}
            >
             Copyright © 2025 | GEN AI - DDP
            </Typography>
          </Box>
        </div>
      </div>
    </div>
  );
};

export default Login;
