import React, { useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { Dialog, Transition } from "@headlessui/react";
import { Fragment } from "react";
import { QuestionMarkCircleIcon } from "@heroicons/react/24/solid";
import API_CONFIG from "../../apiconfig";
import {
  Box,
  Grid,
  Typography,
  TextField,
  Button,
  Card,
  Divider,
  InputAdornment,
  IconButton,
  Stack,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";

const LiteratureMining = () => {
  const { BASE_URL, PORT1 } = API_CONFIG;
  const [fileError, setFileError] = useState("");
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [loading, setLoading] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [queryparams, setqueryparams] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const resultsPerPage = 10;

  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [selectedPreview, setSelectedPreview] = useState(null);
  const handlePreview = (item) => {
    setSelectedPreview(item);
    setIsPreviewOpen(true);
  };
  const formik = useFormik({
    initialValues: {
      proteinName: "",
      dataSource: "",
    },
    validationSchema: Yup.object({
      proteinName: Yup.string().required("Protein Name is required"),
      dataSource: Yup.string().required("Data Source is required"),
    }),
    onSubmit: (values) => {
      console.log(values);
      handleSearch(values);
    },
  });

  const handleSearch = async (keywords) => {
    console.log("key", keywords);
    setSearchLoading(true);
    setLoading(true);
    try {
      const encodedProteinName = encodeURIComponent(
        keywords.proteinName
          .split(",")
          .map((item) => item.trim())
          .join(", ")
      );
      const encodedDataSource = encodeURIComponent(
        keywords.dataSource
          .split(",")
          .map((item) => item.trim())
          .join(", ")
      );
      //const url = `http://20.84.78.153:8080/api/v1/search-keywords/?article_keywords=${encodedProteinName}&search_keywords=${encodedDataSource}`;
      const url = `${BASE_URL}:${PORT1}/api/v1/search-keywords/?article_keywords=${encodedProteinName}&search_keywords=${encodedDataSource}`;
      const response = await axios.get(url);
      setLoading(false);
      console.log("76::", response.data.results)
      setSearchResults(response.data.results);
      setSearchLoading(true);
    } catch (error) {
      console.error("Search Error:", error);
    } finally {
      setSearchLoading(false);
    }
  };

  const indexOfLastResult = currentPage * resultsPerPage;
  const indexOfFirstResult = indexOfLastResult - resultsPerPage;
  console.log("Search Results", searchResults);
  const sortedResults = [...searchResults].sort(
    (a, b) => b.score - a.score
  );
  const currentResults = sortedResults.slice(indexOfFirstResult, indexOfLastResult);
  
  console.log("Current Results", currentResults);
  return (
    <>
      <Transition appear show={isPreviewOpen} as={Fragment}>
        <Dialog
          as="div"
          className="relative z-10"
          onClose={() => setIsPreviewOpen(false)}
        >
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-black bg-opacity-25" />
          </Transition.Child>

          <div className="fixed inset-0 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4 text-center">
              <Transition.Child
                as={Fragment}
                enter="ease-out duration-300"
                enterFrom="opacity-0 scale-95"
                enterTo="opacity-100 scale-100"
                leave="ease-in duration-200"
                leaveFrom="opacity-100 scale-100"
                leaveTo="opacity-0 scale-95"
              >
                <Dialog.Panel className="w-full max-w-2xl max-h-[80vh] overflow-y-auto transform rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all">
                  <div className="mt-2">
                    <p className="text-sm text-gray-700 whitespace-pre-wrap">
                      {selectedPreview?.preview || "No preview available."}
                    </p>
                  </div>

                  <div className="mt-4 sticky bottom-0 bg-white pt-2">
                    <button
                      type="button"
                      className="inline-flex justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                      onClick={() => setIsPreviewOpen(false)}
                    >
                      Close
                    </button>
                  </div>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </div>
        </Dialog>
      </Transition>

      <div>
        <div>
          {/* Left Side Form Controls */}
          <div>
            <Box
              sx={{
                mx: "20px",
                border: "1px solid black",
                borderRadius: 2,
                p: "10px",
                height: "auto", // Ensures height is only as much as needed
                minHeight: "50px", // Adjust as per your requirement
              }}
            >
              {/* Title & Description */}
              <Typography variant="h6" fontWeight={600}>
                Literature Mining
              </Typography>
              <Typography color="textSecondary">
                The Literature Mining step extracts relevant research articles
                from databases like PubMed based on user-specified 
                keywords. It filters and retains only those articles
                containing the specified keywords, ensuring focused and
                high-quality scientific insights for drug discovery.
              </Typography>

              {/* Form Card */}
              <Card
                variant="outlined"
                sx={{ p: 3, mt: 1, borderRadius: 2, boxShadow: 1 }}
              >
                <form onSubmit={formik.handleSubmit}>
                  <Grid container spacing={2} alignItems="center">
                    {/* Protein Search */}
                    <Grid item xs={3.5}>
                      <Stack spacing={1}>
                        <Typography fontWeight={600}>Primary Search</Typography>
                        <TextField
                          fullWidth
                          id="proteinName"
                          name="proteinName"
                          label="Primary Term *"
                          variant="outlined"
                          value={formik.values.proteinName}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          error={
                            formik.touched.proteinName &&
                            Boolean(formik.errors.proteinName)
                          }
                          helperText={
                            formik.touched.proteinName &&
                            formik.errors.proteinName
                          }
                          sx={{
                            "& .MuiInputBase-root": {
                              height: "40px", // Adjust height
                            },
                            "& .MuiInputBase-input": {
                              padding: "8px", // Adjust padding inside the input
                            },
                          }}
                          InputProps={{
                            endAdornment: (
                              <InputAdornment position="end">
                                <IconButton>
                                  <SearchIcon />
                                </IconButton>
                              </InputAdornment>
                            ),
                          }}
                        />
                      </Stack>
                    </Grid>

                    {/* Divider */}
                    <Divider
                      orientation="vertical"
                      flexItem
                      sx={{
                        borderColor: "#333333", // Light black
                        borderWidth: "1px", // Thicker line
                        alignSelf: "stretch", // Ensures it takes full height without extra space
                        marginLeft: "10px",
                      }}
                    />

                    {/* Keyword Search */}
                    <Grid item xs={5.5}>
                      <Stack spacing={1.5}>
                        <Typography fontWeight={600}>Keyword Search</Typography>
                        <TextField
                          fullWidth
                          id="dataSource"
                          name="dataSource"
                          label="Associated Terms *"
                          variant="outlined"
                          value={formik.values.dataSource}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          error={
                            formik.touched.dataSource &&
                            Boolean(formik.errors.dataSource)
                          }
                          helperText={
                            formik.touched.dataSource &&
                            formik.errors.dataSource
                          }
                          sx={{
                            "& .MuiInputBase-root": {
                              height: "40px", // Adjust height
                            },
                            "& .MuiInputBase-input": {
                              padding: "8px", // Adjust padding inside the input
                            },
                          }}
                        />
                      </Stack>
                    </Grid>

                    {/* Search Button */}
                    <Grid item xs={2} textAlign="right">
                      <Button
                        type="submit"
                        variant="contained"
                        sx={{
                          bgcolor: "#0225AA",
                          ":hover": { bgcolor: "#021a80" },
                          width: "100%", // Makes the button take the full width of the Grid item
                          minWidth: "150px", // Ensures the button has a minimum width
                        }}
                      >
                        Search
                      </Button>
                    </Grid>
                  </Grid>
                </form>
              </Card>
            </Box>
          </div>

          {/* Table Section below the form */}
          {loading && (
            <div className="flex justify-center items-center mt-20">
              {" "}
              {/* Moves spinner lower */}
              <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-blue-500 border-solid"></div>{" "}
              {/* Increases size */}
            </div>
          )}
          {!loading && searchResults.length > 0 && (
            <div className="rounded-lg mx-auto w-full max-w-6xl mt-3">
              {" "}
              {/* Increase max-width */}
              <table className="w-full bg-white shadow-md table-auto border-collapse border border-gray-300 text-xs">
                <thead>
                  <tr
                    style={{
                      background:
                        "linear-gradient(180deg, #BACAFF -200%, #0225AA 281.25%)",
                    }}
                  >
                    <th className="border-b px-4 py-2 text-center font-bold text-white">
                      Primary Term
                    </th>
                    <th className="border-b px-4 py-2 text-center font-bold text-white">
                      Title
                    </th>
                    <th className="border-b px-4 py-2 text-center font-bold text-white">
                      Score
                    </th>

                    <th className="border-b px-4 py-2 text-center font-bold text-white">
                      PDF File Path
                    </th>
                    <th className="border-b px-4 py-2 text-center font-bold text-white">
                      Found Keyword
                    </th>
                    <th className="border-b px-4 py-2 text-center font-bold text-white">
                      Preview
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {currentResults.map((item, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="border-b px-4 py-2 text-gray-800 whitespace-nowrap">
                        {item.protein_name}
                      </td>
                      <td className="border-b px-4 py-2 text-gray-800 whitespace-nowrap">
                        {item.title}
                      </td>
                      <td className="border-b px-4 py-2 text-gray-800 whitespace-nowrap">
                        {item.score.toFixed(2)}
                      </td>
                      <td className="border-b px-4 py-2">
                        <a
                          href={item.pdf_file_path}
                          className="text-blue-600 hover:underline"
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {item.title}
                        </a>
                      </td>
                      <td
                        className={`border-b px-4 py-2 ${
                          item.found_keywords
                            ? "text-green-600 font-bold"
                            : "text-gray-500"
                        }`}
                      >
                       {(item.found_keywords || []).join(", ")}
                      </td>
                      <td className="border-b px-4 py-2 text-gray-800 whitespace-nowrap">
                        <button
                          onClick={() => handlePreview(item)}
                          className="text-blue-600 hover:text-blue-800"
                          title="Preview"
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                            strokeWidth={1.5}
                            stroke="currentColor"
                            className="w-5 h-5"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M2.25 12s3.75-6.75 9.75-6.75S21.75 12 21.75 12s-3.75 6.75-9.75 6.75S2.25 12 2.25 12z"
                            />
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                            />
                          </svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {/* Pagination for the table */}
              <div className="flex justify-center mt-6 space-x-4">
                {[
                  ...Array(
                    Math.ceil(searchResults.length / resultsPerPage)
                  ).keys(),
                ].map((number) => (
                  <button
                    key={number}
                    onClick={() => setCurrentPage(number + 1)}
                    className={`px-4 py-2 text-sm font-semibold border rounded-lg transition-colors duration-200 ${
                      currentPage === number + 1
                        ? "bg-blue-600 text-white"
                        : "bg-gray-200 text-gray-700 hover:bg-blue-500 hover:text-white"
                    }`}
                  >
                    {number + 1}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default LiteratureMining;
