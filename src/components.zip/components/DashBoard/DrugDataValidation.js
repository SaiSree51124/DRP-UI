import React, { useEffect, useState } from "react";
import axios from "axios";
import API_CONFIG from "../../apiconfig";
const DrugDataValidation = ({ drugData }) => {
  console.log("drugdata", drugData);
  const { BASE_URL,PORT4 } = API_CONFIG;
  const [data, setdata] = useState([]);
  useEffect(() => {
    fetchValidationData(drugData);
  }, [drugData]);
  const fetchValidationData = async (updatedData) => {
    const response = await axios.post(
      //"http://20.84.78.153:5040/validate",
      `${BASE_URL}:${PORT4}/validate`,
      updatedData,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    const parsedData = response.data.validation_results.map((str) =>
      JSON.parse(str)
    );
    console.log("datavalid", response.data.validation_results);
    setdata(parsedData);
  };

  return (
    <div className="container mx-auto p-6">
      <h2 className="text-2xl font-bold text-center mb-6">Drug Data</h2>

      <div className="overflow-x-auto shadow-md rounded-lg">
        <table className="min-w-full border border-gray-300 bg-white">
          {/* Table Head */}
          <thead>
            <tr className="bg-gray-200 text-gray-700 uppercase text-sm">
              <th className="p-3 border">Compound Name</th>
              <th className="p-3 border">Criteria</th>
              <th className="p-3 border">Validity</th>
            </tr>
          </thead>

          {/* Table Body */}
          <tbody>
            {data?.map((compound, compoundIndex) =>
              compound?.criteria.map((item, index) => (
                <tr
                  key={`${compoundIndex}-${index}`}
                  className="border-b hover:bg-gray-100 transition duration-200"
                >
                  {/* Compound Name (Only show for the first row of each compound) */}
                  <td className="p-3 border font-medium text-center">
                    {index === 0 ? (
                      <span className="font-bold text-blue-600">
                        {compound.compound_name}
                      </span>
                    ) : (
                      ""
                    )}
                  </td>

                  {/* Criteria Name */}
                  {console.log("item is", item)}
                  <td className="p-3 border capitalize">
                    <span className="font-bold">
                      {(item?.step_name || item?.step)?.replace(/_/g, " ")}
                    </span>{" "}
                    : {item?.statement}
                  </td>

                  {/* Validity with color coding */}
                  <td className="p-3 border text-center">
                    <span
                      className={`px-3 py-1 text-sm font-semibold rounded-md ${
                        item.validity === "valid"
                          ? "bg-green-100 text-green-700"
                          : "bg-red-100 text-red-700"
                      }`}
                    >
                      {item?.validity}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// Example Usage

export default DrugDataValidation;
