import React, { useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import { Dialog, Transition } from "@headlessui/react";
import { Fragment } from "react";
import { QuestionMarkCircleIcon } from "@heroicons/react/24/solid";
import Checkbox from "@mui/material/Checkbox";
import API_CONFIG from "../../apiconfig";
import {
  Grid,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";
const NoveltySearchModule = () => {
  const { BASE_URL,PORT1 } = API_CONFIG;
  const [res, setres] = useState({});
  const [llmData, setllmData] = useState({});
  const [loading, setloading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const formik = useFormik({
    initialValues: {
      dataSource: "",
      //llmModel: "",
      searchQuery: "",
      numResults: "",
    },
    validationSchema: Yup.object({
      dataSource: Yup.string().required("Required"),
      // llmModel: Yup.string().required("Required"),
      searchQuery: Yup.string().required("Required"),
      numResults: Yup.number()
        .typeError("Must be a number")
        .min(1, "At least 1 result required")
        .required("Required"),
    }),
    onSubmit: (values) => {
      console.log("Form Values:", values);
      handleNoveltySearch(values);
    },
  });
  const handleNoveltySearch = async (values) => {
    setloading(true);
    const query = values.searchQuery;
    const dataSource = values.dataSource;
    const numberofresults = values.numResults;
    try {
      const response = await axios.get(
       // `http://20.84.78.153:8081/fetch_data?query=${query}&data_source=${dataSource}&num_results=${numberofresults}`
       `${BASE_URL}:${PORT1}/api/v1/fetch_data?query=${query}&data_source=${dataSource}&num_results=${numberofresults}`
      );
      console.log(response);
      setloading(false);
      setres(response.data);
      setllmData({});
    } catch (error) {
      setloading(false);
      toast.error("Error: No response received from the server", {
        position: "top-right",
      });
    }
  };
  const llmFormik = useFormik({
    initialValues: {
      userQuery: "",
      useSearchContext: false,
    },
    validationSchema: Yup.object({
      userQuery: Yup.string().required("Query is required"),
    }),
    onSubmit: async (values) => {
      setloading(true);
      try {
        // http://172.203.208.46:8081/chatbot?user_query=explain covishield patents&use_search_context=true
        // const url = `http://20.84.78.153:8081/chatbot?user_query=${encodeURIComponent(
        //   values.userQuery
        // )}&use_context=${values.useSearchContext}`;
        const url = `${BASE_URL}:${PORT1}/api/v1/chatbot?user_query=${encodeURIComponent(
          values.userQuery
        )}&use_context=${values.useSearchContext}`
        console.log("Calling API:", url);
        const response = await fetch(url);
        setloading(false);
        const responseData = await response.json();
        toast.success("API Call Successful!");

        setllmData(responseData);
        setres({});
        //console.log("Response:", data);
      } catch (error) {
        setloading(false);
        toast.error("API Call Failed!");
        console.error("Error:", error);
      }
    },
  });
  const onDownloadHistory = async()=>{
    //setLoading(true);
const response = await axios.get(
        `${BASE_URL}:${PORT1}/api/v1/download_history`,
        {
          responseType: "text", // get plain text
          // Optionally, you can also try "blob" and treat accordingly
        }
      );
      console.log("111::", response.data)
      const csvText = response.data;
      const blob = new Blob([csvText], { type: "text/csv;charset=utf-8;" });
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = blobUrl;
      const filename = "history.csv";
      link.setAttribute("download", filename);

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Free the blob URL
      window.URL.revokeObjectURL(blobUrl);
  }
  return (
    <>
      <div className="m-1 p-3 border-2 border-gray-600 rounded-md">
        <h1 className="text-[14px] font-bold text-[rgb(37,103,174)]">
          Novelty Search
        </h1>
        <p>
          The Novelty Search module checks if the identified drug candidates are
          truly new by comparing them with existing research papers and patents.
          It uses GenAI to scan scientific literature and databases to find out
          if similar drugs have already been studied or patented. This helps
          researchers focus on unique and innovative drug discoveries, ensuring
          their work leads to something original and valuable....
        </p>
      </div>

      <div className="gap-4 w-full  h-full ">
        {/* ✅ Small Form Section */}
        <div
          className="border-2 border-gray-500 rounded-md"
          style={{ padding: "10px 15px", borderRadius: "6px" }}
        >
          <h2 className="text-lg  mb-4 font-bold">Search Config</h2>
          <form onSubmit={formik.handleSubmit} className="space-y-3">
            <Grid container spacing={2} alignItems="center">
              {/* Data Source Dropdown */}
              <Grid item xs={3}>
                <FormControl fullWidth variant="outlined">
                  <InputLabel>Data Source</InputLabel>
                  <Select
                    name="dataSource"
                    value={formik.values.dataSource}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    label="Data Source"
                    sx={{
                      height: "40px", // Adjust the height
                      fontSize: "14px", // Reduce font size if needed
                      padding: "4px 8px", // Adjust padding for better fit
                    }}
                  >
                    <MenuItem value="">Select</MenuItem>
                    <MenuItem value="Google CSE">Google CSE</MenuItem>
                    <MenuItem value="Google Patents API">
                      Google Patents API
                    </MenuItem>
                    <MenuItem value="Wikipedia">Wikipedia</MenuItem>
                    <MenuItem value="PubMed">PubMed</MenuItem>
                    <MenuItem value="All Combined">All Combined</MenuItem>
                  </Select>
                </FormControl>
                {formik.touched.dataSource && formik.errors.dataSource && (
                  <p className="text-red-500 text-xs mt-1">
                    {formik.errors.dataSource}
                  </p>
                )}
              </Grid>

              {/* Search Query Input */}
              <Grid item xs={3}>
                <TextField
                  fullWidth
                  label="Search Query"
                  name="searchQuery"
                  value={formik.values.searchQuery}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  variant="outlined"
                  size="small"
                  error={
                    formik.touched.searchQuery &&
                    Boolean(formik.errors.searchQuery)
                  }
                  helperText={
                    formik.touched.searchQuery && formik.errors.searchQuery
                  }
                />
              </Grid>

              {/* Number of Results Input */}
              <Grid item xs={2}>
                <TextField
                  fullWidth
                  label="Number of Results"
                  name="numResults"
                  value={formik.values.numResults}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  variant="outlined"
                  size="small"
                  error={
                    formik.touched.numResults &&
                    Boolean(formik.errors.numResults)
                  }
                  helperText={
                    formik.touched.numResults && formik.errors.numResults
                  }
                />
              </Grid>

              {/* Submit Button */}
              <Grid item xs={2}>
                <Button
                  type="submit"
                  variant="contained"
                  sx={{ backgroundColor: "#0225AA" }}
                  fullWidth
                >
                  Fetch Data
                </Button>
              </Grid>
              <Grid item xs={2}>
                <Button
                  type="button"
                  variant="contained"
                  sx={{ backgroundColor: "#0225AA" }}
                  fullWidth
                  onClick={onDownloadHistory}
                >
                  History
                </Button>
              </Grid>
            </Grid>
          </form>

          <hr className="border-gray-300 my-4" />
          <h2 className="text-lg  mb-4 font-bold">Query</h2>
          <form onSubmit={llmFormik.handleSubmit} className="space-y-3">
            <Grid container spacing={2} alignItems="center">
              {/* User Query Input */}
              <Grid item xs={5}>
                <TextField
                  fullWidth
                  label="Query"
                  name="userQuery"
                  onChange={llmFormik.handleChange}
                  onBlur={llmFormik.handleBlur}
                  value={llmFormik.values.userQuery}
                  variant="outlined"
                  size="small"
                  error={
                    llmFormik.touched.userQuery &&
                    Boolean(llmFormik.errors.userQuery)
                  }
                  helperText={
                    llmFormik.touched.userQuery && llmFormik.errors.userQuery
                  }
                />
              </Grid>

              {/* Use Search Context Checkbox */}
              <Grid item xs={3} container alignItems="center">
                <div className="flex items-center">
                  <Checkbox
                    name="useSearchContext"
                    onChange={llmFormik.handleChange}
                    checked={llmFormik.values.useSearchContext}
                  />
                  <label className="text-sm">Use Search Context</label>
                </div>
              </Grid>

              {/* Submit Button */}
              <Grid item xs={2}>
                <Button
                  type="submit"
                  variant="contained"
                  fullWidth
                  sx={{
                    border: "2px solid #0225AA",
                    color: "#0225AA",
                    backgroundColor: "#ffffff",
                    fontWeight: "600",
                    "&:hover": {
                      backgroundColor: "#f0f0f0", // Slightly different shade on hover
                    },
                  }}
                >
                  Query LLM
                </Button>
              </Grid>
              {/*<Grid item xs={2}>
                <Button
                  type="submit"
                  variant="contained"
                  sx={{ backgroundColor: "#0225AA" }}
                  fullWidth
                >
                  Export
                </Button>
              </Grid> */}
            </Grid>
          </form>
        </div>

        {/* ✅ Right Side (Takes Remaining Width) */}
        <div>
          {loading && (
            <div className="flex justify-center items-center mt-20">
              {" "}
              {/* Moves spinner lower */}
              <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-blue-500 border-solid"></div>{" "}
              {/* Increases size */}
            </div>
          )}
          {!loading && (Object.keys(res).length > 0 || llmData.response) && (
            <div className="shadow-lg p-5">
              {/* Google Patents Section */}
              {res["Google CSE"]?.length > 0 && (
                <div className="mb-8">
                  <h2 className="text-3xl font-bold text-white-900 mb-6">
                    Google CSE
                  </h2>
                  {res["Google CSE"].map((patent) => (
                    <div key={patent.paper_id}>
                      <p className="font-bold text-gray-800 mt-2">Title:</p>
                      <p
                        className="text-gray-700"
                        dangerouslySetInnerHTML={{ __html: patent.Title }}
                      />
                      <p className="font-bold text-gray-800">Snippet:</p>
                      <p
                        className="text-gray-700"
                        dangerouslySetInnerHTML={{ __html: patent.Snippet }}
                      />

                      <p className="font-bold text-black-800 mb-2">
                        Link:{" "}
                        <a
                          href={patent.Link.startsWith("https") ? patent.Link : `https://${patent.Link}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-blue-600"
                        >
                          {patent.Link}
                        </a>
                      </p>
                      <hr style={{
      backgroundColor: "#808080",    // Sets fill color
      height: "1px",          // Defines thickness
      border: 'none',             // Remove default border
    }}></hr>
                    </div>
                  ))}
                </div>
              )}
              {res["Google Patents API"]?.length > 0 && (
                <div className="mb-8">
                  <h2 className="text-3xl font-bold text-white-900 mb-6">
                    Google Patents (API)
                  </h2>
                  {res["Google Patents API"].map((patent) => (
                    <div key={patent.paper_id}>
                      <p className="font-bold text-gray-800 mt-2">Title:</p>
                      <p
                        className="text-gray-700"
                        dangerouslySetInnerHTML={{ __html: patent.Title }}
                      />
                      <p className="font-bold text-gray-800">Snippet:</p>
                      <p
                        className="text-gray-700"
                        dangerouslySetInnerHTML={{ __html: patent.Snippet }}
                      />

                      <p className="font-bold text-black-800 mb-2">
                        Link:{" "}
                        <a
                          href={patent.Link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-blue-600"
                        >
                          {patent.Link}
                        </a>
                      </p>
                      <hr style={{
      backgroundColor: "#808080",    // Sets fill color
      height: "1px",          // Defines thickness
      border: 'none',             // Remove default border
    }}></hr>
                    </div>
                  ))}
                </div>
              )}
              {/* Wikipedia Section */}
              {res["Wikipedia"]?.error ? (
                <section className="mt-6">
                  <h2 className="text-3xl font-semibold mb-4 text-gray-900">
                    Wikipedia
                  </h2>
                  <p className="text-red-600 text-lg">
                    {res["Wikipedia"].error}
                  </p>
                </section>
              ) : (
                res["Wikipedia"]?.length > 0 && (
                  <section className="mt-6">
                    <h2 className="text-3xl font-semibold mb-6 text-gray-900">
                      Wikipedia
                    </h2>
                    {res["Wikipedia"].map((wiki) => (
                      <div key={wiki.page_id}>
                        <p className="font-bold text-gray-800 mt-2">Title:</p>
                      <p
                        className="text-gray-700"
                        dangerouslySetInnerHTML={{ __html: wiki.Title }}
                      />
                      <p className="font-bold text-gray-800">Snippet:</p>
                      <p
                        className="text-gray-700"
                        dangerouslySetInnerHTML={{ __html: wiki.Snippet }}
                      />
                      <p className="font-bold text-black-800 mb-2">
                        Link:{" "}
                        <a
                          href={wiki.Link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-blue-600"
                        >
                          {wiki.Link}
                        </a>
                      </p>
                      </div>
                    ))}
                  </section>
                )
              )}

              {/* PubMed Section */}
              {res["PubMed"]?.length > 0 ? (
                <section className="mt-6">
                  <h2 className="text-3xl font-semibold mb-6 text-white-900">
                    PubMed Articles
                  </h2>
                  {res["PubMed"].map((article) => (
                    <div key={article.id} className="mb-4">
                      <p className="font-bold text-gray-800 mt-2">Title:</p>
                      <p
                        className="text-gray-700"
                        dangerouslySetInnerHTML={{ __html: article.Title }}
                      />
                      <p className="font-bold text-gray-800">Snippet:</p>
                      <p
                        className="text-gray-700"
                        dangerouslySetInnerHTML={{ __html: article.Snippet }}
                      />
                      <p className="font-bold text-black-800 mb-2">
                        Link:{" "}
                        <a
                          href={article.Link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-blue-600"
                        >
                          {article.Link}
                        </a>
                      </p>
                    </div>
                  ))}
                </section>
              ) : (
                <></>
              )}
              {llmData.response && (
                <div className=" mx-auto p-6 bg-white shadow-lg rounded-lg">
                  <h1 className="text-2xl font-bold text-gray-800">
                    Description
                  </h1>

                  <p className="mt-4 text-gray-700">{llmData.response}</p>
                </div>
              )}
            </div>
          )}
        </div>
        <ToastContainer />
      </div>
    </>
  );
};

export default NoveltySearchModule;
