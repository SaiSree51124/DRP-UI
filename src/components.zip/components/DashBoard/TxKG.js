//TxKG component for Target Identification 
import React, { useState, useEffect } from "react";
import axios from "axios";
import API_CONFIG from "../../apiconfig";
import KGSubgraph from "./KGSubgraph";
import KGNodeAttention from "./KGNodeAttention";
import KGMetaPath from "./KGMetaPath";

import {
  Box,
  Typography,
  //FormControl,
  //Select,
  //MenuItem,
  Grid,
  Button,
  Paper,
  Autocomplete,
  TextField,
  CircularProgress,
} from "@mui/material";

const TxKG = () => {
  const { BASE_URL, PORT5 } = API_CONFIG;
  const API_BASE_URL = `${BASE_URL}:${PORT5}/api/txkg`;

  const [selectedDisease, setSelectedDisease] = useState("");
  const [diseases, setDiseases] = useState([]);
  const [targets, setTargets] = useState([]);
  //const [drugs, setDrugs] = useState([]);
  const [llmInterpretation, setLlmInterpretation] = useState("");
  const [articles, setArticles] = useState([]);
  const [graphData, setGraphData] = useState(null);

  const [loadingDiseases, setLoadingDiseases] = useState(false);
  const [loadingTargets, setLoadingTargets] = useState(false);
  //const [loadingDrugs, setLoadingDrugs] = useState(false);
  const [loadingLLM, setLoadingLLM] = useState(false);
  const [loadingArticles, setLoadingArticles] = useState(false);
  const [loadingGraph, setLoadingGraph] = useState(false);

  const [activeTab, setActiveTab] = useState("Sub-Graph");

  // Fetch diseases on component mount
  useEffect(() => {
    fetchDiseases();
  }, []);

  // Fetch data when disease changes
  useEffect(() => {
    if (selectedDisease) {
      fetchTargets(selectedDisease);
      //fetchDrugs(selectedDisease);
      fetchLLMInterpretation(selectedDisease);
      fetchArticles(selectedDisease);
      fetchGraphData(selectedDisease, activeTab);
    }
  }, [selectedDisease]);

  // Fetch graph data when tab changes
  useEffect(() => {
    if (selectedDisease && activeTab) {
      fetchGraphData(selectedDisease, activeTab);
    }
  }, [activeTab]);

  // Endpoint 1: GET /diseases - Fetch list of available diseases
  const fetchDiseases = async () => {
    try {
      setLoadingDiseases(true);
      const response = await axios.get(`${API_BASE_URL}/diseases`);
      console.log("Fetched diseases:", response.data);

      // Normalize — backend returns { diseases: [{id, name}, ...] }
      const diseasesArray = Array.isArray(response.data.diseases)
        ? response.data.diseases
        : [];

      setDiseases(diseasesArray);
    } catch (error) {
      console.error("Error fetching diseases:", error);
      // Fallback data
      const fallbackNames = [
        "Schizophrenia",
        "Alzheimer Disease",
        "Diabetes",
        "Cancer",
        "Parkinson Disease",
      ];
      const fallbackDiseases = fallbackNames.map((n, i) => ({
        id: `F${i}`,
        name: n,
      }));
      setDiseases(fallbackDiseases);
      setSelectedDisease(fallbackDiseases[0].name);
    } finally {
      setLoadingDiseases(false);
    }
  };

  // Endpoint 2: GET /predicted-targets?disease={name}
  const fetchTargets = async (disease) => {
    try {
      setLoadingTargets(true);
      const response = await axios.get(`${API_BASE_URL}/predicted-targets`, {
        params: { disease },
      });

      // Handles both cases: array or { targets: [...] }
      setTargets(response.data.targets || response.data || []);
    } catch (error) {
      console.error("Error fetching targets:", error);
      // Fallback mock data with UniProt IDs
      setTargets([
        {
          uniprot_id: "P14416",
          name: "D(2) dopamine receptor",
          score: 0.95,
        },
        {
          uniprot_id: "P28223",
          name: "5-hydroxytryptamine receptor 2A",
          score: 0.89,
        },
        {
          uniprot_id: "Q12879",
          name: "Glutamate receptor ionotropic, NMDA 2A",
          score: 0.84,
        },
        {
          uniprot_id: "P31645",
          name: "Sodium-dependent serotonin transporter",
          score: 0.78,
        },
        {
          uniprot_id: "P21964",
          name: "Catechol O-methyltransferase",
          score: 0.72,
        },
        {
          uniprot_id: "Q13936",
          name: "Voltage-dependent L-type calcium channel subunit alpha-1C",
          score: 0.7,
        },
        { uniprot_id: "Q9ULB1", name: "Neurexin-1", score: 0.68 },
      ]);
    } finally {
      setLoadingTargets(false);
    }
  };
 
  // Endpoint 3: GET /llm-interpretation?disease={name}
  const fetchLLMInterpretation = async (disease) => {
    try {
      setLoadingLLM(true);
      const response = await axios.get(`${API_BASE_URL}/llm-interpretation`, {
        params: { disease },
      });

      setLlmInterpretation(response.data.interpretation || response.data.text || "");
    } catch (error) {
      console.error("Error fetching LLM interpretation:", error);
      setLlmInterpretation(
        `The predicted targets and drugs for ${disease} show promising therapeutic potential. ` +
          `The targets identified are key proteins involved in the disease pathway. ` +
          `Further research and clinical validation are recommended.`
      );
    } finally {
      setLoadingLLM(false);
    }
  };

  // Endpoint 4: GET /articles?disease={name}
  const fetchArticles = async (disease) => {
    try {
      setLoadingArticles(true);
      const response = await axios.get(`${API_BASE_URL}/articles`, {
        params: { disease },
      });

      setArticles(
        response.data.articles || response.data.sources || response.data || []
      );
    } catch (error) {
      console.error("Error fetching articles:", error);
      setArticles([
        { title: "Sample Article 1", url: "#", source: "PubMed" },
        { title: "Sample Article 2", url: "#", source: "Nature" },
        { title: "Sample Article 3", url: "#", source: "Science" },
      ]);
    } finally {
      setLoadingArticles(false);
    }
  };

  // Endpoint 5: Fetch graph visualization data based on active tab
  const fetchGraphData = async (disease, tabType) => {
    try {
      setLoadingGraph(true);
      let endpoint = "";

      switch (tabType) {
        case "Sub-Graph":
          endpoint = `${API_BASE_URL}/subgraph`;
          break;
        case "Node Attention":
          endpoint = `${API_BASE_URL}/node-attention`;
          break;
        case "Meta-Path":
          endpoint = `${API_BASE_URL}/metapath`;
          break;
        default:
          endpoint = `${API_BASE_URL}/subgraph`;
      }

      const response = await axios.get(endpoint, {
        params: { disease },
      });

      setGraphData(response.data);
    } catch (error) {
      console.error(`Error fetching ${tabType} data:`, error);
      setGraphData(null);
    } finally {
      setLoadingGraph(false);
    }
  };

 
  // Render appropriate graph based on active tab
  const renderGraphVisualization = () => {
    switch (activeTab) {
      case "Sub-Graph":
        return <KGSubgraph graphData={graphData} loading={loadingGraph} />;
      case "Node Attention":
        return <KGNodeAttention graphData={graphData} loading={loadingGraph} />;
      case "Meta-Path":
        return <KGMetaPath graphData={graphData} loading={loadingGraph} />;
      default:
        return <KGSubgraph graphData={graphData} loading={loadingGraph} />;
    }
  }; 

  return (
    <Box sx={{ mx: "20px" }}>
      {/* Header */}
      <Box
        sx={{ mb: 3, p: "10px", border: "1px solid black", borderRadius: 2 }}
      >
        <Typography variant="h6" fontWeight={600}>
          TxKG - Therapeutic Target & Drug Prediction
        </Typography>
        <Typography mt={1} color="text.secondary" textAlign="justify">
          The TxKG module leverages advanced graph neural networks to predict
          potential therapeutic targets and drug candidates for various
          diseases. By analyzing complex biological networks and disease
          pathways, TxKG identifies promising gene/protein targets and compounds
          that could be developed into effective treatments. This AI-powered
          system helps researchers discover novel drug-disease associations and
          accelerates the drug discovery process by providing data-driven
          predictions with confidence scores.
        </Typography>
      </Box>

      {/* Disease Selection (Autocomplete) */}
      <Box sx={{ mb: 3, display: "flex", alignItems: "center", gap: 2 }}>
        <Typography fontWeight={600}>Diseases:</Typography>

        <Autocomplete
          sx={{
            minWidth: 300,
            "& .MuiOutlinedInput-root": {
              bgcolor: "#0225AA",
              color: "white",
              "& .MuiOutlinedInput-notchedOutline": {
                borderColor: "#ffffff",
              },
              "&:hover .MuiOutlinedInput-notchedOutline": {
                borderColor: "#ffffff",
              },
              "& .MuiSvgIcon-root": {
                color: "white",
              },
            },
            "& .MuiAutocomplete-listbox": {
              bgcolor: "#0225AA",
              color: "white",
              "& .MuiAutocomplete-option:hover": {
                backgroundColor: "#0033cc",
                color: "white",
              },
            },
          }}
          options={diseases.map((d) => d.name)}
          value={selectedDisease || null}
          onChange={(event, newValue) => {
            setSelectedDisease(newValue || "");
          }}
          loading={loadingDiseases}
          clearOnEscape
          renderInput={(params) => (
            <TextField
              {...params}
              placeholder="Search for a disease..."
              variant="outlined"
              InputProps={{
                ...params.InputProps,
                style: { color: "white" },
                endAdornment: (
                  <>
                    {loadingDiseases ? (
                      <CircularProgress color="inherit" size={20} />
                    ) : null}
                    {params.InputProps.endAdornment}
                  </>
                ),
              }}
            />
          )}
        />
      </Box>

      {/* Main Content */}
      <Grid container spacing={2}>
        {/* Left Section: Targets & Drugs */}
        <Grid item xs={12} md={7}>
          {/* Targets Table */}
          <Box sx={{ mb: 3 }}>
            <Paper
              elevation={2}
              sx={{
                border: "0px solid #0225AA",
                borderRadius: 1,
                overflow: "hidden",
              }}
            >
              <Box
                sx={{
                  background:
                    "linear-gradient(180deg, #BACAFF -200%, #0225AA 281.25%)",
                  color: "white",
                  p: 1.5,
                  display: "flex",
                  justifyContent: "space-between",
                }}
              >
                <Typography fontWeight={600} sx={{ width: "33%" }}>
                  Uniprot ID
                </Typography>
                <Typography
                  fontWeight={600}
                  sx={{ width: "33%", textAlign: "center" }}
                >
                  Target
                </Typography>
                <Typography
                  fontWeight={600}
                  sx={{ width: "33%", textAlign: "right" }}
                >
                  Score
                </Typography>
              </Box>

              <Box sx={{ p: 1.5 }}>
                {loadingTargets ? (
                  <Typography sx={{ p: 2, textAlign: "center", color: "#666" }}>
                    Loading targets...
                  </Typography>
                ) : targets.length > 0 ? (
                  targets.map((target, idx) => (
                    <Box
                      key={idx}
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        p: 1.5,
                        borderBottom: "1px solid #e0e0e0",
                        cursor: "pointer",
                        "&:hover": { bgcolor: "#d3deffff" },
                      }}
                    >
                      <Typography sx={{ width: "15%" }}>
                        {target.uniprot_id || "-"}
                      </Typography>
                      <Typography
                        sx={{ width: "60%", textAlign: "center" }}
                        fontWeight={500}
                        color="black"
                      >
                        {target.name || target.gene || target.protein || "-"}
                      </Typography>
                      <Typography
                        sx={{ width: "15%", textAlign: "right" }}
                        fontWeight={500}
                        color="black"
                      >
                        {(target.score || 0).toFixed(2)}
                      </Typography>
                    </Box>
                  ))
                ) : (
                  <Typography sx={{ p: 2, textAlign: "center", color: "#999" }}>
                    No targets predicted
                  </Typography>
                )}
              </Box>
            </Paper>
          </Box>
        </Grid>

        {/* Right Section: LLM & Articles */}
        <Grid item xs={12} md={5}>
          <Grid container direction="column" spacing={2}>
            {/* LLM Interpretation */}
            <Grid item>
              <Paper
                elevation={2}
                sx={{
                  border: "2px solid #0225AA",
                  borderRadius: 2,
                  p: 2,
                }}
              >
                <Typography
                  variant="h6"
                  color="#0225AA"
                  fontWeight={600}
                  mb={1}
                >
                  LLM Interpretation:
                </Typography>
                <Box
                  sx={{
                    minHeight: 150,
                    maxHeight: 250,
                    overflowY: "auto",
                    lineHeight: 1.6,
                  }}
                >
                  {loadingLLM ? (
                    <Typography color="#666" fontStyle="italic">
                      Loading interpretation...
                    </Typography>
                  ) : llmInterpretation ? (
                    <Typography>{llmInterpretation}</Typography>
                  ) : (
                    <Typography color="#666">
                      Select a disease to see AI interpretation of the
                      predictions.
                    </Typography>
                  )}
                </Box>
              </Paper>
            </Grid>

            {/* Articles/Sources */}
            <Grid item>
              <Paper
                elevation={2}
                sx={{
                  border: "0px solid #2c5f7c",
                  borderRadius: 1,
                  overflow: "hidden",
                }}
              >
                <Box
                  sx={{
                    background:
                      "linear-gradient(180deg, #BACAFF -200%, #0225AA 281.25%)",
                    color: "white",
                    p: 1.5,
                  }}
                >
                  <Typography fontWeight={600}>Articles/Sources</Typography>
                </Box>
                <Box sx={{ p: 2, maxHeight: 200, overflowY: "auto" }}>
                  {loadingArticles ? (
                    <Typography color="#666" fontStyle="italic">
                      Loading articles...
                    </Typography>
                  ) : articles.length > 0 ? (
                    articles.map((article, idx) => (
                      <Box
                        key={idx}
                        sx={{
                          mb: 1,
                          pb: 1,
                          borderBottom:
                            idx < articles.length - 1
                              ? "1px solid #e0e0e0"
                              : "none",
                        }}
                      >
                        <a
                          href={article.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{
                            color: "#0225AA",
                            textDecoration: "none",
                            fontSize: "14px",
                          }}
                          onMouseEnter={(e) =>
                            (e.currentTarget.style.textDecoration = "underline")
                          }
                          onMouseLeave={(e) =>
                            (e.currentTarget.style.textDecoration = "none")
                          }
                        >
                          {article.title}
                        </a>
                        {article.source && (
                          <Typography
                            component="span"
                            sx={{ ml: 1, color: "#666", fontSize: 12 }}
                          >
                            ({article.source})
                          </Typography>
                        )}
                      </Box>
                    ))
                  ) : (
                    <Typography color="#999" textAlign="center">
                      No articles available
                    </Typography>
                  )}
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </Grid>
      </Grid>

      {/* Graph Visualization Section */}
      <Box
        sx={{
          mt: 4,
          border: "0px solid #0225AA",
          borderRadius: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            display: "flex",
            borderBottom: "0px solid #2c5f7c",
            background:
              "linear-gradient(180deg, #BACAFF -200%, #0225AA 281.25%)",
          }}
        >
          {["Sub-Graph", "Node Attention", "Meta-Path"].map((tab) => (
            <Button
              key={tab}
              onClick={() => setActiveTab(tab)}
              sx={{
                flex: 1,
                py: 1.5,
                fontWeight: activeTab === tab ? "bold" : 500,
                bgcolor: activeTab === tab ? "white" : "transparent",
                color: activeTab === tab ? "#0225AA" : "white",
                borderRadius: 0,
                "&:hover": {
                  bgcolor: activeTab === tab ? "white" : "#e0e0e0",
                  color: activeTab === tab ? "#0225AA" : "black",
                },
              }}
            >
              {tab}
            </Button>
          ))}
        </Box>
        <Box
          sx={{
            minHeight: 300,
            maxHeight: 600,
            overflowY: "auto",
            bgcolor: "#fafafa",
          }}
        >
          {renderGraphVisualization()}
        </Box>
      </Box>
    </Box>
  );
};

export default TxKG;