import React, { useState } from "react";
import DrugDataCollection from "./DrugDataCollection";
import DrugDataValidation from "./DrugDataValidation";
import { Dialog, Transition } from "@headlessui/react";
import { Fragment } from "react";
import { QuestionMarkCircleIcon } from "@heroicons/react/24/solid";
const DataCurationEngine = () => {
  const [activeTab, setActiveTab] = useState(0); // Default to first tab
  const [drugData, setDrugData] = useState(null);
const [isOpen, setIsOpen] = useState(false);
  const handleTabClick = (index) => {
    // Prevent switching to "Drug Data Validation" if no data
    if (index === 1 && !drugData) return;
    setActiveTab(index);
  };

  // Tab names and corresponding content
  const tabs = [
    { name: "Drug Data Collection and Validation", index: 0, component: <DrugDataCollection setDrugData={setDrugData}/> },
   /* { name: "Drug Data Validation", index: 1, component: <DrugDataValidation drugData={drugData}/>  },*/
  ];

  return (
    <>
    <div className="shadow-md m-1 p-3 flex items-center justify-between">
        <h1
          className="text-[14px] font-bold text-[rgb(37,103,174)]"
          style={{ color: "rgb(37,103,174)" }}
        >
          Data Curation Engine
        </h1>
        <button
          onClick={() => setIsOpen(true)}
          className="ml-4 p-1 w-8 h-8 rounded-full text-white flex items-center justify-center"
          style={{backgroundColor:"#2567ae"}}
        >
          <QuestionMarkCircleIcon className="w-4 h-4" />
        </button>
      </div>
      <Transition show={isOpen} as={Fragment}>
        <Dialog
          as="div"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50"
          onClose={() => setIsOpen(false)}
        >
          <Dialog.Panel className="w-full max-w-3xl bg-white rounded-lg shadow-lg p-6">
            <Dialog.Title className="text-lg font-semibold text-gray-800">
              Data Curation Engine
            </Dialog.Title>
            <Dialog.Description className="mt-2 text-gray-600">
            <span className="font-bold">The Data Curation Engine</span> collects ligand data based on user-defined criteria using <span className="font-bold">LLMs</span> and verifies their presence in specified reference sources. This step ensures that only validated, high-confidence drug candidates proceed for further screening and analysis.
            </Dialog.Description>
            <div className="mt-4 flex justify-end">
              <button
                onClick={() => setIsOpen(false)}
                className="px-4 py-2  text-white rounded-lg"
                style={{backgroundColor:"#2567ae"}}
              >
                Close
              </button>
            </div>
          </Dialog.Panel>
        </Dialog>
      </Transition>
    <div className="container mx-auto mt-6">
      {/* Tab Buttons */}
     
      <div className="flex border-b-2 border-gray-300">
      {tabs.map((tab, index) => (
          <button
            key={index}
            onClick={() => handleTabClick(index)}
            className={`py-2 px-6 font-medium transition-all duration-200 ${
              activeTab === index
                ? "border-b-4 border-blue-500 text-blue-500"
                : !drugData && index === 1
                ? "text-gray-400 cursor-not-allowed" // Disable Drug Data Validation tab
                : "text-gray-500 hover:text-gray-700"
            }`}
            style={{color:"rgb(37,103,174)"}}
            disabled={index === 1 && !drugData} // Prevent clicking
          >
            {tab.name}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="mt-4">
        {tabs[activeTab]?.component} {/* Render active tab's component */}
      </div>
    </div>
    </>
  );
};

export default DataCurationEngine;
