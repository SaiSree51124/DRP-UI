import React from "react";
import { Box, Paper, Typography } from "@mui/material";

const KGMetaPath = ({ graphData, loading }) => {
  if (loading) {
    return (
      <Box sx={{ p: 3, textAlign: "center" }}>
        <Typography color="#666">Loading meta-paths...</Typography>
      </Box>
    );
  }

  if (!graphData || !graphData.metapaths) {
    return (
      <Box sx={{ p: 3, textAlign: "center" }}>
        <Typography color="#666">No meta-path data available</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="subtitle1" mb={2} color="#0225AA" fontWeight={600}>
        {graphData.metadata?.description || "Therapeutic meta-paths"}
      </Typography>

      {graphData.metapaths?.slice(0, 8).map((path, idx) => (
        <Paper
          key={path.id}
          sx={{
            p: 2,
            mb: 2,
            bgcolor: "#f9f9f9",
            border: "1px solid #e0e0e0",
          }}
        >
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              mb: 1,
            }}
          >
            <Typography fontWeight={600} color="#0225AA">
              Path {idx + 1}
            </Typography>
            <Typography fontSize={14} fontWeight={600} color="#FF6B6B">
              Score: {path.path_score.toFixed(3)}
            </Typography>
          </Box>

          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1,
              mb: 1,
              flexWrap: "wrap",
            }}
          >
            {path.nodes?.map((node, nodeIdx) => (
              <React.Fragment key={node.id}>
                <Box
                  sx={{
                    p: 1,
                    bgcolor:
                      node.type === "disease"
                        ? "#FF6B6B"
                        : node.type === "protein"
                        ? "#4ECDC4"
                        : "#95E1D3",
                    color: node.type === "compound" ? "black" : "white",
                    borderRadius: 1,
                    minWidth: 80,
                    textAlign: "center",
                  }}
                >
                  <Typography fontSize={11} fontWeight={600}>
                    {node.type.toUpperCase()}
                  </Typography>
                  <Typography fontSize={13}>{node.label}</Typography>
                </Box>
                {nodeIdx < path.nodes.length - 1 && (
                  <Typography fontSize={20} color="#0225AA" fontWeight={600}>
                    →
                  </Typography>
                )}
              </React.Fragment>
            ))}
          </Box>

          <Typography
            fontSize={12}
            color="text.secondary"
            sx={{ fontStyle: "italic" }}
          >
            {path.description}
          </Typography>
        </Paper>
      ))}

      <Box sx={{ mt: 2, pt: 2, borderTop: "1px solid #e0e0e0" }}>
        <Typography fontSize={13} color="text.secondary">
          Showing top {Math.min(8, graphData.metapaths?.length || 0)} therapeutic pathways
        </Typography>
      </Box>
    </Box>
  );
};

export default KGMetaPath;
