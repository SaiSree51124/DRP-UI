import React from "react";
import { Box, Typography, Paper, Grid } from "@mui/material";

const KGNodeAttention = ({ graphData, loading }) => {
  if (loading) {
    return (
      <Box sx={{ p: 3, textAlign: "center" }}>
        <Typography color="#666">Loading attention weights...</Typography>
      </Box>
    );
  }

  if (!graphData || !graphData.attention_data) {
    return (
      <Box sx={{ p: 3, textAlign: "center" }}>
        <Typography color="#666">No attention data available</Typography>
      </Box>
    );
  }

  const attentionData = graphData.attention_data;

  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="subtitle1" mb={2} color="#0225AA" fontWeight={600}>
        {graphData.metadata?.description || "Node attention weights"}
      </Typography>

      {/* Statistics */}
      {attentionData.statistics && (
        <Paper sx={{ p: 2, mb: 2, bgcolor: "#f5f5f5" }}>
          <Typography fontWeight={600} mb={1}>
            Network Statistics:
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <Typography fontSize={14}>
                High Importance Targets:{" "}
                {attentionData.statistics.high_importance_targets}
              </Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography fontSize={14}>
                High Importance Drugs:{" "}
                {attentionData.statistics.high_importance_drugs}
              </Typography>
            </Grid>
          </Grid>
        </Paper>
      )}

      {/* Protein Targets */}
      <Box sx={{ mb: 3 }}>
        <Typography fontWeight={600} mb={1} color="#0225AA">
          Protein Targets (by attention weight):
        </Typography>
        {attentionData.target_nodes?.slice(0, 10).map((node) => (
          <Box
            key={node.id}
            sx={{
              p: 1.5,
              mb: 1,
              bgcolor: "#fff",
              border: "1px solid #e0e0e0",
              borderRadius: 1,
            }}
          >
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                mb: 0.5,
              }}
            >
              <Typography fontWeight={500}>{node.label}</Typography>
              <Typography fontSize={14} color="#0225AA" fontWeight={600}>
                {node.attention_weight.toFixed(3)}
              </Typography>
            </Box>
            <Box
              sx={{
                width: "100%",
                height: 8,
                bgcolor: "#e0e0e0",
                borderRadius: 1,
                overflow: "hidden",
              }}
            >
              <Box
                sx={{
                  width: `${node.attention_weight * 100}%`,
                  height: "100%",
                  bgcolor:
                    node.importance === "high"
                      ? "#4ECDC4"
                      : node.importance === "medium"
                      ? "#95E1D3"
                      : "#ddd",
                  transition: "width 0.3s",
                }}
              />
            </Box>
          </Box>
        ))}
      </Box>

      {/* Drug Candidates */}
      <Box>
        <Typography fontWeight={600} mb={1} color="#0225AA">
          Drug Candidates (by attention weight):
        </Typography>
        {attentionData.drug_nodes?.slice(0, 10).map((node) => (
          <Box
            key={node.id}
            sx={{
              p: 1.5,
              mb: 1,
              bgcolor: "#fff",
              border: "1px solid #e0e0e0",
              borderRadius: 1,
            }}
          >
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                mb: 0.5,
              }}
            >
              <Typography fontWeight={500}>{node.label}</Typography>
              <Typography fontSize={14} color="#0225AA" fontWeight={600}>
                {node.attention_weight.toFixed(3)}
              </Typography>
            </Box>
            <Box
              sx={{
                width: "100%",
                height: 8,
                bgcolor: "#e0e0e0",
                borderRadius: 1,
                overflow: "hidden",
              }}
            >
              <Box
                sx={{
                  width: `${node.attention_weight * 100}%`,
                  height: "100%",
                  bgcolor:
                    node.importance === "high"
                      ? "#FF6B6B"
                      : node.importance === "medium"
                      ? "#FFA07A"
                      : "#ddd",
                  transition: "width 0.3s",
                }}
              />
            </Box>
          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default KGNodeAttention;
