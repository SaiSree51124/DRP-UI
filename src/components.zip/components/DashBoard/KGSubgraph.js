import React, { useEffect, useState } from "react";
import axios from "axios";

const KGSubgraph = ({ disease, API_BASE_URL }) => {
  const [graphUrl, setGraphUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchSubgraph = async () => {
      if (!disease) return;
      setLoading(true);
      setError(null);

      try {
        await axios.get(`${API_BASE_URL}/subgraph`, {
          params: { disease },
        });

        const htmlPath = `${API_BASE_URL}/graphs/kg_graph.html?t=${Date.now()}`;
        setGraphUrl(htmlPath);
      } catch (err) {
        console.error("Error fetching subgraph:", err);
        setError("Failed to load subgraph.");
      } finally {
        setLoading(false);
      }
    };

    fetchSubgraph();
  }, [disease, API_BASE_URL]);

  if (loading) return <p>Loading subgraph...</p>;
  if (error) return <p style={{ color: "red" }}>{error}</p>;

  return (
    graphUrl && (
      <iframe
        src={graphUrl}
        title="Knowledge Graph"
        width="100%"
        height="600px"
        style={{
          border: "none",
          borderRadius: "8px",
        }}
      />
    )
  );
};

export default KGSubgraph;
