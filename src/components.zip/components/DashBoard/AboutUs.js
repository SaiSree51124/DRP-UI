import React from "react";
import { Typography, Box } from "@mui/material";

const AboutUs = () => {
  return (
    <>
      <Box sx={{ padding: 2 }}>
        <Typography variant="h6" fontWeight="bold">
          Introduction to the Platform
        </Typography>
        <Typography variant="body1" sx={{ marginTop: 1 }}>
          The <strong>GenAI-Based Drug Discovery Platform</strong> harnesses
          Generative AI and automation to accelerate drug discovery, making the
          process faster, more efficient, and cost-effective. By leveraging
          Virtual screening techniques and data-driven insights, it helps
          Pharmaceutical, and Biotech companies identify promising drug
          candidates with greater accuracy, optimizing research efforts and
          improving success rates in therapeutic development.
        </Typography>
      </Box>
      <Box
  sx={{
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    width: "100%",
    overflow: "hidden",
  }}
>
  <img 
    src="/processflow.png" 
    alt="Process Flow"
    style={{
      maxWidth: "100%",
      maxHeight: "100%",
      objectFit: "contain",
    }}
  />
</Box>

      <Box sx={{ padding: 2 }}>
      <Typography variant="h6" fontWeight="bold">
          Steps:
        </Typography>
        <Typography variant="body1" paragraph>
          <strong>Literature Mining</strong> extracts relevant research articles from databases like <strong>PubMed</strong> based on user-specified protein names and keywords. It filters and retains only those articles containing the specified keywords, ensuring focused and high-quality scientific insights for drug discovery.
        </Typography>

        <Typography variant="body1" paragraph>
          <strong>Data Curation Engine</strong> collects ligand data based on user-defined criteria using <strong>LLMs</strong> and verifies their presence in specified reference sources. This step ensures that only validated, high-confidence drug candidates proceed for further screening and analysis.
        </Typography>

        <Typography variant="body1" paragraph>
          <strong>Screening Suite</strong> is responsible for <strong>retrieving, preparing, and virtually screening drug candidates</strong> against target proteins. It automates molecular structure downloads, optimizes ligand and protein files, and performs <strong>high-throughput docking using AutoDock Vina</strong>. Post-docking analysis integrates the <strong>PLIP (Protein-Ligand Interaction Profiler) module</strong> to analyze interactions such as <strong>hydrogen bonds, hydrophobic contacts, salt bridges, and π-stacking</strong>. This ensures a comprehensive evaluation of ligand-protein binding, helping to prioritize the most effective drug candidates for further development.
        </Typography>

        <Typography variant="body1" paragraph>
          <strong>Novelty Search</strong> checks if the identified drug candidates are truly new by comparing them with existing research papers and patents. It uses <strong>GenAI</strong> to scan scientific literature and databases to determine if similar drugs have already been studied or patented. This helps researchers focus on <strong>unique and innovative</strong> drug discoveries, ensuring their work leads to something original and valuable...
        </Typography>
      </Box>
    </>
  );
};

export default AboutUs;
