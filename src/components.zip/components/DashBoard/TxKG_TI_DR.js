//TxKg code for Target Identification and Drug Repurposing tables using fetch()
import React, { useState, useEffect } from "react";
import API_CONFIG from "../../apiconfig";
import {
  Box,
  Typography,
  FormControl,
  Select,
  MenuItem,
  Grid,
  Button,
  Paper,
  Autocomplete,
  TextField,
  CircularProgress,
} from "@mui/material";

const TxKG = () => {
  const { BASE_URL, PORT5 } = API_CONFIG;
  const [selectedDisease, setSelectedDisease] = useState('');   // keep blank initially
  const [diseases, setDiseases] = useState([]);      // list of {id, name}
  const [targets, setTargets] = useState([]);
  const [drugs, setDrugs] = useState([]);
  const [llmInterpretation, setLlmInterpretation] = useState("");
  const [articles, setArticles] = useState([]);
  const [graphData, setGraphData] = useState(null);

  const [loadingDiseases, setLoadingDiseases] = useState(false);
  const [loadingTargets, setLoadingTargets] = useState(false);
  const [loadingDrugs, setLoadingDrugs] = useState(false);
  const [loadingLLM, setLoadingLLM] = useState(false);
  const [loadingArticles, setLoadingArticles] = useState(false);
  const [loadingGraph, setLoadingGraph] = useState(false);

  const [activeTab, setActiveTab] = useState("Sub-Graph");


  // Fetch diseases on component mount
  useEffect(() => {
    fetchDiseases();
  }, []);

  // Fetch data when disease changes
  useEffect(() => {
    if (selectedDisease) {
      fetchTargets(selectedDisease);
      fetchDrugs(selectedDisease);
      fetchLLMInterpretation(selectedDisease);
      fetchArticles(selectedDisease);
      fetchGraphData(selectedDisease, activeTab);
    }
  }, [selectedDisease]);

  // Fetch graph data when tab changes
  useEffect(() => {
    if (selectedDisease && activeTab) {
      fetchGraphData(selectedDisease, activeTab);
    }
  }, [activeTab]);

  // Endpoint 1: GET /diseases - Fetch list of available diseases
  const fetchDiseases = async () => {
    try {
      setLoadingDiseases(true);
      const response = await fetch(`${BASE_URL}:${PORT5}/api/txkg/diseases`);
      const data = await response.json();
      console.log("Fetched diseases:", data);

       // Normalize — backend returns { diseases: [{id, name}, ...] }
      const diseasesArray = Array.isArray(data.diseases) ? data.diseases : [];

      setDiseases(diseasesArray);

      // DO NOT auto-select the first disease — keep the input empty for user to type
    // if you want to preselect later, setSelectedDisease(diseasesArray[0].name);
      // if (diseasesArray.length > 0) {
        // setSelectedDisease(diseasesArray[0].name);}

    } catch (error) {
    console.error("Error fetching diseases:", error);
    // fallback as before but now array of strings -> convert to objects
    const fallbackNames = [
      "Schizophrenia",
      "Alzheimer Disease",
      "Diabetes",
      "Cancer",
      "Parkinson Disease",
    ];
    const fallbackDiseases = fallbackNames.map((n, i) => ({ id: `F${i}`, name: n }));
    setDiseases(fallbackDiseases);
    setSelectedDisease(fallbackDiseases[0].name);
  } finally {
    setLoadingDiseases(false);
  }
};

  // Endpoint 2: GET /predicted-targets?disease={name}
  const fetchTargets = async (disease) => {
    try {
      setLoadingTargets(true);
      const response = await fetch(
        `${BASE_URL}:${PORT5}/api/txkg/predicted-targets?disease=${encodeURIComponent(disease)}`
      );
      const data = await response.json();
      
      // Handles both cases: array or { targets: [...] }
      setTargets(data.targets || data || []);
      setLoadingTargets(false);
    } catch (error) {
      console.error("Error fetching targets:", error);
    // Fallback mock data with UniProt IDs
      setTargets([
      { "uniprot_id": "P14416", "name": "D(2) dopamine receptor", "score": 0.95 },
      { "uniprot_id": "P28223", "name": "5-hydroxytryptamine receptor 2A", "score": 0.89 },
      { "uniprot_id": "Q12879", "name": "Glutamate receptor ionotropic, NMDA 2A", "score": 0.84 },
      { "uniprot_id": "P31645", "name": "Sodium-dependent serotonin transporter", "score": 0.78 },
      { "uniprot_id": "P21964", "name": "Catechol O-methyltransferase", "score": 0.72 },
      { "uniprot_id": "Q13936", "name": "Voltage-dependent L-type calcium channel subunit alpha-1C", "score": 0.70 },
      { "uniprot_id": "Q9ULB1", "name": "Neurexin-1", "score": 0.68 },
    ]);
  } finally {
    setLoadingTargets(false);
  }
};

  // Endpoint 3: GET /predicted-drugs?disease={name}
  const fetchDrugs = async (disease) => {
    try {
      setLoadingDrugs(true);
      const response = await fetch(
        `${BASE_URL}:${PORT5}/api/txkg/predicted-drugs?disease=${encodeURIComponent(disease)}`
      );
      const data = await response.json();

      setDrugs(data.drugs || data.compounds || data || []);
      setLoadingDrugs(false);
    } catch (error) {
      console.error("Error fetching drugs:", error);
      setLoadingDrugs(false);
      setDrugs([
        { name: "Risperidone", score: 0.92 },
        { name: "Clozapine", score: 0.88 },
        { name: "Olanzapine", score: 0.85 },
        { name: "Quetiapine", score: 0.81 },
        { name: "Aripiprazole", score: 0.76 },
      ]);
    }
  };

  // Endpoint 4: GET /llm-interpretation?disease={name}
  const fetchLLMInterpretation = async (disease) => {
    try {
      setLoadingLLM(true);
      const response = await fetch(
        `${BASE_URL}:${PORT5}/api/txkg/llm-interpretation?disease=${encodeURIComponent(disease)}`
      );
      const data = await response.json();

      setLlmInterpretation(data.interpretation || data.text || "");
      setLoadingLLM(false);
    } catch (error) {
      console.error("Error fetching LLM interpretation:", error);
      setLoadingLLM(false);
      setLlmInterpretation(
        `The predicted targets and drugs for ${disease} show promising therapeutic potential. ` +
        `The targets identified are key proteins involved in the disease pathway. ` +
        `Further research and clinical validation are recommended.`
      );
    }
  };

  // Endpoint 5: GET /articles?disease={name}
  const fetchArticles = async (disease) => {
    try {
      setLoadingArticles(true);
      const response = await fetch(
        `${BASE_URL}:${PORT5}/api/txkg/articles?disease=${encodeURIComponent(disease)}`
      );
      const data = await response.json();

      setArticles(data.articles || data.sources || data || []);
      setLoadingArticles(false);
    } catch (error) {
      console.error("Error fetching articles:", error);
      setLoadingArticles(false);
      setArticles([
        { title: "Sample Article 1", url: "#", source: "PubMed" },
        { title: "Sample Article 2", url: "#", source: "Nature" },
        { title: "Sample Article 3", url: "#", source: "Science" },
      ]);
    }
  };

  // NEW: Fetch graph visualization data based on active tab
  const fetchGraphData = async (disease, tabType) => {
    try {
      setLoadingGraph(true);
      let endpoint = "";
      
      switch(tabType) {
        case "Sub-Graph":
          endpoint = `${BASE_URL}:${PORT5}/api/txkg/subgraph?disease=${encodeURIComponent(disease)}`;
          break;
        case "Node Attention":
          endpoint = `${BASE_URL}:${PORT5}/api/txkg/node-attention?disease=${encodeURIComponent(disease)}`;
          break;
        case "Meta-Path":
          endpoint = `${BASE_URL}:${PORT5}/api/txkg/metapath?disease=${encodeURIComponent(disease)}`;
          break;
        default:
          endpoint = `${BASE_URL}:${PORT5}/api/txkg/subgraph?disease=${encodeURIComponent(disease)}`;
      }
      
      const response = await fetch(endpoint);
      const data = await response.json();
      setGraphData(data);
      setLoadingGraph(false);
    } catch (error) {
      console.error(`Error fetching ${tabType} data:`, error);
      setLoadingGraph(false);
      setGraphData(null);
    }
  };

  const handleDiseaseChange = (event) => {
    setSelectedDisease(event.target.value);
  };

  // Render Sub-Graph visualization
  const renderSubGraph = () => {
    if (loadingGraph) {
      return (
        <Box sx={{ p: 3, textAlign: "center" }}>
          <Typography color="#666">Loading sub-graph...</Typography>
        </Box>
      );
    }

    if (!graphData || !graphData.nodes) {
      return (
        <Box sx={{ p: 3, textAlign: "center" }}>
          <Typography color="#666">No sub-graph data available</Typography>
        </Box>
      );
    }

    return (
      <Box sx={{ p: 2 }}>
        <Typography variant="subtitle1" mb={2} color="#0225AA" fontWeight={600}>
          {graphData.metadata?.description || "Disease-centered sub-graph"}
        </Typography>
        
        {/* Graph Nodes Display */}
        <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {/* Disease Node (Center) */}
          {graphData.nodes?.filter(n => n.type === "disease").map((node) => (
            <Box key={node.id} sx={{ textAlign: "center" }}>
              <Paper
                sx={{
                  p: 2,
                  bgcolor: "#FF6B6B",
                  color: "white",
                  display: "inline-block",
                  minWidth: 150,
                }}
              >
                <Typography fontSize={12} fontWeight={600}>DISEASE</Typography>
                <Typography fontSize={16} fontWeight={700}>{node.label}</Typography>
              </Paper>
            </Box>
          ))}

          {/* Protein Nodes */}
          <Box>
            <Typography fontSize={14} fontWeight={600} mb={1} color="#0225AA">
              Associated Proteins:
            </Typography>
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1.5 }}>
              {graphData.nodes?.filter(n => n.type === "protein").map((node) => (
                <Paper
                  key={node.id}
                  sx={{
                    p: 1.5,
                    bgcolor: "#4ECDC4",
                    color: "white",
                    minWidth: 100,
                    textAlign: "center",
                  }}
                >
                  <Typography fontSize={12} fontWeight={600}>PROTEIN</Typography>
                  <Typography fontSize={14}>{node.label}</Typography>
                  {node.score && (
                    <Typography fontSize={11} mt={0.5}>
                      {node.score.toFixed(2)}
                    </Typography>
                  )}
                </Paper>
              ))}
            </Box>
          </Box>

          {/* Drug Nodes */}
          <Box>
            <Typography fontSize={14} fontWeight={600} mb={1} color="#0225AA">
              Therapeutic Compounds:
            </Typography>
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1.5 }}>
              {graphData.nodes?.filter(n => n.type === "compound").map((node) => (
                <Paper
                  key={node.id}
                  sx={{
                    p: 1.5,
                    bgcolor: "#95E1D3",
                    color: "black",
                    minWidth: 100,
                    textAlign: "center",
                  }}
                >
                  <Typography fontSize={12} fontWeight={600}>DRUG</Typography>
                  <Typography fontSize={14}>{node.label}</Typography>
                  {node.score && (
                    <Typography fontSize={11} mt={0.5}>
                      {node.score.toFixed(2)}
                    </Typography>
                  )}
                </Paper>
              ))}
            </Box>
          </Box>
        </Box>

        <Box sx={{ mt: 2, pt: 2, borderTop: "1px solid #e0e0e0" }}>
          <Typography fontSize={13} color="text.secondary">
            Network: {graphData.nodes?.length || 0} nodes, {graphData.edges?.length || 0} connections
          </Typography>
        </Box>
      </Box>
    );
  };

  // Render Node Attention visualization
  const renderNodeAttention = () => {
    if (loadingGraph) {
      return (
        <Box sx={{ p: 3, textAlign: "center" }}>
          <Typography color="#666">Loading attention weights...</Typography>
        </Box>
      );
    }

    if (!graphData || !graphData.attention_data) {
      return (
        <Box sx={{ p: 3, textAlign: "center" }}>
          <Typography color="#666">No attention data available</Typography>
        </Box>
      );
    }

    const attentionData = graphData.attention_data;

    return (
      <Box sx={{ p: 2 }}>
        <Typography variant="subtitle1" mb={2} color="#0225AA" fontWeight={600}>
          {graphData.metadata?.description || "Node attention weights"}
        </Typography>

        {/* Statistics */}
        {attentionData.statistics && (
          <Paper sx={{ p: 2, mb: 2, bgcolor: "#f5f5f5" }}>
            <Typography fontWeight={600} mb={1}>Network Statistics:</Typography>
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Typography fontSize={14}>
                  High Importance Targets: {attentionData.statistics.high_importance_targets}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography fontSize={14}>
                  High Importance Drugs: {attentionData.statistics.high_importance_drugs}
                </Typography>
              </Grid>
            </Grid>
          </Paper>
        )}

        {/* Target Nodes */}
        <Box sx={{ mb: 3 }}>
          <Typography fontWeight={600} mb={1} color="#0225AA">
            Protein Targets (by attention weight):
          </Typography>
          {attentionData.target_nodes?.slice(0, 10).map((node) => (
            <Box
              key={node.id}
              sx={{
                p: 1.5,
                mb: 1,
                bgcolor: "#fff",
                border: "1px solid #e0e0e0",
                borderRadius: 1,
              }}
            >
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 0.5 }}>
                <Typography fontWeight={500}>{node.label}</Typography>
                <Typography fontSize={14} color="#0225AA" fontWeight={600}>
                  {node.attention_weight.toFixed(3)}
                </Typography>
              </Box>
              <Box
                sx={{
                  width: "100%",
                  height: 8,
                  bgcolor: "#e0e0e0",
                  borderRadius: 1,
                  overflow: "hidden",
                }}
              >
                <Box
                  sx={{
                    width: `${node.attention_weight * 100}%`,
                    height: "100%",
                    bgcolor: node.importance === "high" ? "#4ECDC4" : node.importance === "medium" ? "#95E1D3" : "#ddd",
                    transition: "width 0.3s",
                  }}
                />
              </Box>
            </Box>
          ))}
        </Box>

        {/* Drug Nodes */}
        <Box>
          <Typography fontWeight={600} mb={1} color="#0225AA">
            Drug Candidates (by attention weight):
          </Typography>
          {attentionData.drug_nodes?.slice(0, 10).map((node) => (
            <Box
              key={node.id}
              sx={{
                p: 1.5,
                mb: 1,
                bgcolor: "#fff",
                border: "1px solid #e0e0e0",
                borderRadius: 1,
              }}
            >
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 0.5 }}>
                <Typography fontWeight={500}>{node.label}</Typography>
                <Typography fontSize={14} color="#0225AA" fontWeight={600}>
                  {node.attention_weight.toFixed(3)}
                </Typography>
              </Box>
              <Box
                sx={{
                  width: "100%",
                  height: 8,
                  bgcolor: "#e0e0e0",
                  borderRadius: 1,
                  overflow: "hidden",
                }}
              >
                <Box
                  sx={{
                    width: `${node.attention_weight * 100}%`,
                    height: "100%",
                    bgcolor: node.importance === "high" ? "#FF6B6B" : node.importance === "medium" ? "#FFA07A" : "#ddd",
                    transition: "width 0.3s",
                  }}
                />
              </Box>
            </Box>
          ))}
        </Box>
      </Box>
    );
  };

  // Render Meta-Path visualization
  const renderMetaPath = () => {
    if (loadingGraph) {
      return (
        <Box sx={{ p: 3, textAlign: "center" }}>
          <Typography color="#666">Loading meta-paths...</Typography>
        </Box>
      );
    }

    if (!graphData || !graphData.metapaths) {
      return (
        <Box sx={{ p: 3, textAlign: "center" }}>
          <Typography color="#666">No meta-path data available</Typography>
        </Box>
      );
    }

    return (
      <Box sx={{ p: 2 }}>
        <Typography variant="subtitle1" mb={2} color="#0225AA" fontWeight={600}>
          {graphData.metadata?.description || "Therapeutic meta-paths"}
        </Typography>

        {graphData.metapaths?.slice(0, 8).map((path, idx) => (
          <Paper
            key={path.id}
            sx={{
              p: 2,
              mb: 2,
              bgcolor: "#f9f9f9",
              border: "1px solid #e0e0e0",
            }}
          >
            <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1 }}>
              <Typography fontWeight={600} color="#0225AA">
                Path {idx + 1}
              </Typography>
              <Typography fontSize={14} fontWeight={600} color="#FF6B6B">
                Score: {path.path_score.toFixed(3)}
              </Typography>
            </Box>

            {/* Path Visualization */}
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 1,
                mb: 1,
                flexWrap: "wrap",
              }}
            >
              {path.nodes?.map((node, nodeIdx) => (
                <React.Fragment key={node.id}>
                  <Box
                    sx={{
                      p: 1,
                      bgcolor:
                        node.type === "disease"
                          ? "#FF6B6B"
                          : node.type === "protein"
                          ? "#4ECDC4"
                          : "#95E1D3",
                      color: node.type === "compound" ? "black" : "white",
                      borderRadius: 1,
                      minWidth: 80,
                      textAlign: "center",
                    }}
                  >
                    <Typography fontSize={11} fontWeight={600}>
                      {node.type.toUpperCase()}
                    </Typography>
                    <Typography fontSize={13}>{node.label}</Typography>
                  </Box>
                  {nodeIdx < path.nodes.length - 1 && (
                    <Typography fontSize={20} color="#0225AA" fontWeight={600}>
                      →
                    </Typography>
                  )}
                </React.Fragment>
              ))}
            </Box>

            <Typography fontSize={12} color="text.secondary" sx={{ fontStyle: "italic" }}>
              {path.description}
            </Typography>
          </Paper>
        ))}

        <Box sx={{ mt: 2, pt: 2, borderTop: "1px solid #e0e0e0" }}>
          <Typography fontSize={13} color="text.secondary">
            Showing top {Math.min(8, graphData.metapaths?.length || 0)} therapeutic pathways
          </Typography>
        </Box>
      </Box>
    );
  };

  // Render appropriate graph based on active tab
  const renderGraphVisualization = () => {
    switch (activeTab) {
      case "Sub-Graph":
        return renderSubGraph();
      case "Node Attention":
        return renderNodeAttention();
      case "Meta-Path":
        return renderMetaPath();
      default:
        return renderSubGraph();
    }
  };

  return (
    <Box sx={{ mx: "20px" }}>
      {/* Header - Introductory Box */}
      <Box sx={{ mb: 3, p: "10px", border: "1px solid black", borderRadius: 2 }}>
        <Typography variant="h6" fontWeight={600}>
          TxKG - Therapeutic Target & Drug Prediction
        </Typography>
        <Typography mt={1} color="text.secondary" textAlign="justify">
          The TxKG module leverages advanced graph neural networks to predict potential
          therapeutic targets and drug candidates for various diseases. By analyzing
          complex biological networks and disease pathways, TxKG identifies promising
          gene/protein targets and compounds that could be developed into effective treatments.
          This AI-powered system helps researchers discover novel drug-disease associations and
          accelerates the drug discovery process by providing data-driven predictions
          with confidence scores.
        </Typography>
      </Box>

{/* Disease Selection (Autocomplete) */}
<Box sx={{ mb: 3, display: "flex", alignItems: "center", gap: 2 }}>
  <Typography fontWeight={600}>Diseases:</Typography>

  <Autocomplete
    sx={{
      minWidth: 300,
      "& .MuiOutlinedInput-root": {
        bgcolor: "#0225AA",
        color: "white",
        "& .MuiOutlinedInput-notchedOutline": {
          borderColor: "#ffffff",
        },
        "&:hover .MuiOutlinedInput-notchedOutline": {
          borderColor: "#ffffff",
        },
        "& .MuiSvgIcon-root": {
          color: "white",
        },
      },
      "& .MuiAutocomplete-listbox": {
        bgcolor: "#0225AA",
        color: "white",
        "& .MuiAutocomplete-option:hover": {
          backgroundColor: "#0033cc",
          color: "white",
        },
      },
    }}
    options={diseases.map((d) => d.name)} // array of disease names
    value={selectedDisease || null} // show empty box when ''  or current selected disease name
    onChange={(event, newValue) => {
      setSelectedDisease(newValue || "");
    }}
    loading={loadingDiseases}
    clearOnEscape
    renderInput={(params) => (
      <TextField
        {...params}
        placeholder="Search for a disease..."
        variant="outlined"
        InputProps={{
          ...params.InputProps,
          style: { color: "white" },
          endAdornment: (
            <>
              {loadingDiseases ? <CircularProgress color="inherit" size={20} /> : null}
              {params.InputProps.endAdornment}
            </>
          ),
        }}
      />
    )}
  />
</Box>


      {/* Main Content */}
      <Grid container spacing={2}>
        {/* Left Section: Targets & Drugs */}
        <Grid item xs={12} md={7}>
          {/* Targets Table */}
          <Box sx={{ mb: 3 }}>
            <Paper
              elevation={2}
              sx={{
                border: "0px solid #0225AA",
                borderRadius: 1,
                overflow: "hidden",
              }}
            >
              {/* Header */}
              <Box
                sx={{
                  background:
                    "linear-gradient(180deg, #BACAFF -200%, #0225AA 281.25%)",
                  color: "white",
                  p: 1.5,
                  display: "flex",
                  justifyContent: "space-between",
                }}
              >
                <Typography fontWeight={600} sx={{ width: "33%"}}>
                  Uniprot ID 
                </Typography>
                <Typography fontWeight={600} sx= {{width: "33%", textAlign: "center"}}>
                  Target
                </Typography>
                <Typography fontWeight={600} sx= {{width: "33%", textAlign: "right"}}>
                  Score
                </Typography>
              </Box>

              {/* Table Body */}
              <Box sx={{ p: 1.5 }}>
                {loadingTargets ? (
                  <Typography sx={{ p: 2, textAlign: "center", color: "#666" }}>
                    Loading targets...
                  </Typography>
                ) : targets.length > 0 ? (
                  targets.map((target, idx) => (
                    <Box
                      key={idx}
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        p: 1.5,
                        borderBottom: "1px solid #e0e0e0",
                        cursor: "pointer",
                        "&:hover": { bgcolor: "#d3deffff" },
                      }}
                    >
                      {/* UniProt ID */}
                      <Typography sx={{ width: "15%"}}>
                         {target.uniprot_id || "-"}
                      </Typography>

                      {/* Target Name */}
                      <Typography 
                      sx={{ width:"60%",textAlign: "center"}}
                      fontWeight={500} color="black" >
                         {target.name || target.gene || target.protein || "-"}
                      </Typography>
                      
                      {/* Score */}
                      <Typography 
                      sx={{ width:"15%", textAlign: "right"}}
                      fontWeight={500} color="black">
                        {(target.score || 0).toFixed(2)}
                      </Typography>
                    </Box>
                  ))
                ) : (
                  <Typography sx={{ p: 2, textAlign: "center", color: "#999" }}>
                    No targets predicted
                  </Typography>
                )}
              </Box>
            </Paper>
          </Box>

          {/* Drugs Table */}
          <Box>
            <Paper
              elevation={2}
              sx={{
                border: "0px solid #0225AA",
                borderRadius: 1,
                overflow: "hidden",
              }}
            >
              <Box
                sx={{
                  background:
                    "linear-gradient(180deg, #BACAFF -200%, #0225AA 281.25%)",
                  color: "white",
                  p: 1.5,
                  display: "flex",
                  justifyContent: "space-between",
                }}
              >
                <Typography fontWeight={600}>Compound</Typography>
                <Typography fontWeight={600}>Score</Typography>
              </Box>
              <Box sx={{ maxHeight: 400, overflowY: "auto" }}>
                {loadingDrugs ? (
                  <Typography sx={{ p: 2, textAlign: "center", color: "#666" }}>
                    Loading drugs...
                  </Typography>
                ) : drugs.length > 0 ? (
                  drugs.map((drug, idx) => (
                    <Box
                      key={idx}
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        p: 1.5,
                        borderBottom: "1px solid #e0e0e0",
                        cursor: "pointer",
                        "&:hover": { bgcolor: "#d3deffff" },
                      }}
                    >
                      <Typography fontWeight={500}>
                        {drug.name || drug.compound || drug.drug}
                      </Typography>
                      <Typography fontWeight={500} color="black">
                        {(drug.score || 0).toFixed(2)}
                      </Typography>
                    </Box>
                  ))
                ) : (
                  <Typography sx={{ p: 2, textAlign: "center", color: "#999" }}>
                    No drugs predicted
                  </Typography>
                )}
              </Box>
            </Paper>
          </Box>
        </Grid>

        {/* Right Section: LLM & Articles */}
        <Grid item xs={12} md={5}>
          <Grid container direction="column" spacing={2}>
            {/* LLM Interpretation */}
            <Grid item>
              <Paper
                elevation={2}
                sx={{
                  border: "2px solid #0225AA",
                  borderRadius: 2,
                  p: 2,
                }}
              >
                <Typography variant="h6" color="#0225AA" fontWeight={600} mb={1}>
                  LLM Interpretation:
                </Typography>
                <Box
                  sx={{
                    minHeight: 150,
                    maxHeight: 250,
                    overflowY: "auto",
                    lineHeight: 1.6,
                  }}
                >
                  {loadingLLM ? (
                    <Typography color="#666" fontStyle="italic">
                      Loading interpretation...
                    </Typography>
                  ) : llmInterpretation ? (
                    <Typography>{llmInterpretation}</Typography>
                  ) : (
                    <Typography color="#666">
                      Select a disease to see AI interpretation of the predictions.
                    </Typography>
                  )}
                </Box>
              </Paper>
            </Grid>

            {/* Articles/Sources */}
            <Grid item>
              <Paper
                elevation={2}
                sx={{
                  border: "0px solid #2c5f7c",
                  borderRadius: 1,
                  overflow: "hidden",
                }}
              >
                <Box
                  sx={{
                    background:
                      "linear-gradient(180deg, #BACAFF -200%, #0225AA 281.25%)",
                    color: "white",
                    p: 1.5,
                  }}
                >
                  <Typography fontWeight={600}>Articles/Sources</Typography>
                </Box>
                <Box sx={{ p: 2, maxHeight: 200, overflowY: "auto" }}>
                  {loadingArticles ? (
                    <Typography color="#666" fontStyle="italic">
                      Loading articles...
                    </Typography>
                  ) : articles.length > 0 ? (
                    articles.map((article, idx) => (
                      <Box
                        key={idx}
                        sx={{
                          mb: 1,
                          pb: 1,
                          borderBottom:
                            idx < articles.length - 1 ? "1px solid #e0e0e0" : "none",
                        }}
                      >
                        <a
                          href={article.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{
                            color: "#0225AA",
                            textDecoration: "none",
                            fontSize: "14px",
                          }}
                          onMouseEnter={(e) =>
                            (e.currentTarget.style.textDecoration = "underline")
                          }
                          onMouseLeave={(e) =>
                            (e.currentTarget.style.textDecoration = "none")
                          }
                        >
                          {article.title}
                        </a>
                        {article.source && (
                          <Typography
                            component="span"
                            sx={{ ml: 1, color: "#666", fontSize: 12 }}
                          >
                            ({article.source})
                          </Typography>
                        )}
                      </Box>
                    ))
                  ) : (
                    <Typography color="#999" textAlign="center">
                      No articles available
                    </Typography>
                  )}
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </Grid>
      </Grid>

      {/* Graph Visualization Section */}
      <Box
        sx={{
          mt: 4,
          border: "0px solid #0225AA",
          borderRadius: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            display: "flex",
            borderBottom: "0px solid #2c5f7c",
            background:
              "linear-gradient(180deg, #BACAFF -200%, #0225AA 281.25%)",
          }}
        >
          {["Sub-Graph", "Node Attention", "Meta-Path"].map((tab) => (
            <Button
              key={tab}
              onClick={() => setActiveTab(tab)}
              sx={{
                flex: 1,
                py: 1.5,
                fontWeight: activeTab === tab ? "bold" : 500,
                bgcolor: activeTab === tab ? "white" : "transparent",
                color: activeTab === tab ? "#0225AA" : "white",
                borderRadius: 0,
                "&:hover": {
                  bgcolor: activeTab === tab ? "white" : "#e0e0e0",
                  color: activeTab === tab ? "#0225AA" : "black",
                },
              }}
            >
              {tab}
            </Button>
          ))}
        </Box>
        <Box
          sx={{
            minHeight: 300,
            maxHeight: 600,
            overflowY: "auto",
            bgcolor: "#fafafa",
          }}
        >
          {renderGraphVisualization()}
        </Box>
      </Box>
    </Box>
  );
};

export default TxKG;