import React, { useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import API_CONFIG from "../../apiconfig";

import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import {  Card,
  Typography,
  TextField,
  Box,
  IconButton,
  Tooltip,Grid, FormControl,Button } from "@mui/material";
const DrugDataCollection = ({ setDrugData }) => {
  const { BASE_URL,PORT1 } = API_CONFIG;
  console.log("BASEURL",BASE_URL,PORT1)
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [compounds, setcompounds] = useState([]);

  const formik = useFormik({
    initialValues: {
      story_content: "",
    },
    validationSchema: Yup.object({
      story_content: Yup.string()
        .trim()
        .required("Story content is required"),
    }),
    onSubmit: async (values, { resetForm }) => {
      setLoading(true);
      setMessage("");
      console.log("Val")
      try {
        const response = await axios.post(
          // "http://20.84.78.153:5030/fetch_compounds",
          `${BASE_URL}:${PORT1}/api/v1/drug-curation/fetch_compounds`,
          values,
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );
        setMessage("✅ Successfully Fetched!");
        console.log("46::", response.data.compounds);
        console.log("47::",response.data)
        setcompounds(response.data.compounds);
        setDrugData(response.data);
        resetForm();
      } catch (error) {
        setMessage("❌ Error While Fetching. Please try again.");
      } finally {
        setLoading(false);
      }
    },
  });

  return (
    <>
      <div>
        <Box
          sx={{
            mx: "20px",
            border: "1px solid black",
            borderRadius: 2,
            p: "10px",  // Left & Right padding
        // Bottom padding
            height: "auto", // Ensures height is only as much as needed
            minHeight: "50px", // Adjust as per your requirement
          }}
        >
          {/* Header Section */}
          <Box
            display="flex"
            justifyContent="space-between"
            alignItems="center"
          >
            <Typography variant="h6" fontWeight={600}>
              Drug Curation Engine
            </Typography>
            {/* <Tooltip title="Information">
              <IconButton>
                <InfoOutlinedIcon />
              </IconButton>
            </Tooltip> */}
          </Box>

          {/* Description */}
          <Typography color="text.secondary">
            The Data Curation Engine collects ligand data based on user-defined
            criteria using LLMs and verifies their presence in specified
            reference sources. This step ensures that only validated,
            high-confidence drug candidates proceed for further screening and
            analysis...
          </Typography>

          {/* Drug Data & Visualization */}
          <Typography mt={1} fontWeight={600}>
            Drug Data
          </Typography>

          {/* Drug Story Content */}

          <form onSubmit={formik.handleSubmit}>
            <Grid container spacing={2} alignItems="center">
              {/* Form Control */}
              <Grid item xs={10}>
                <FormControl fullWidth>
                  <TextField
                    fullWidth
                    multiline
                    minRows={5}
                    variant="outlined"
                    name="story_content"
                    value={formik.values.story_content}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    error={
                      formik.touched.story_content &&
                      Boolean(formik.errors.story_content)
                    }
                    helperText={
                      formik.touched.story_content &&
                      formik.errors.story_content
                    }
                    sx={{
                      borderRadius: 2,
                      backgroundColor: "#f8f9fa",
                    }}
                  />
                </FormControl>
              </Grid>

              {/* Fetch Drug List Button */}
              <Grid item xs={2} textAlign="right">
                <Button
                type="submit" 
                  variant="contained"
                  sx={{ bgcolor: "#0225AA", ":hover": { bgcolor: "#021a80" } }}
                >
                  Fetch Drug List
                </Button>
              </Grid>
            </Grid>
          </form>

          {/* Note Section */}
          <Typography
          
            fontSize={12}
            fontWeight={500}
            color="text.secondary"
          >
            <strong>*Note:</strong> Specify the criteria that the LLM should
            follow for optimal results.
          </Typography>
        </Box>
      </div>
      {loading && (
        <div className="flex justify-center items-center mt-20">
          {" "}
          {/* Moves spinner lower */}
          <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-blue-500 border-solid"></div>{" "}
          {/* Increases size */}
        </div>
      )}
      {!loading && compounds.length > 0 && (
        <div className="mx-auto mt-8 px-4">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300 shadow-lg rounded-lg">
              <thead style={{ background: "linear-gradient(180deg, #BACAFF -200%, #0225AA 281.25%)"}}>
                <tr>
                  <th className="p-3 border">Compound Name</th>
                  <th className="p-3 border">Content</th>
                  <th className="p-3 border">Confidence Score</th>
                  <th className="p-3 border">Websites</th>
                </tr>
              </thead>
              <tbody>
                {compounds.map((compound, index) => (
                  <tr
                    key={index}
                    className="bg-white hover:bg-gray-100 transition"
                  >
                    <td className="p-3 border font-semibold">
                      {compound["compound_name"]}
                    </td>
                    <td className="p-3 border text-left">
  {Object.entries(compound.content).map(([key, value]) => (
    <div key={key} className="mb-2">
      <span className="font-semibold">{key}:</span>{" "}
      {typeof value === "object" && value !== null
        ? Object.entries(value).map(([k2, v2]) => (
            <div key={k2} style={{ marginLeft: "1em" }}>
              <span className="font-semibold">{k2}:</span> {v2}
            </div>
          ))
        : value}
    </div>
  ))}
</td>

                    <td className="p-3 border text-center">
                      {compound["confidence_score"]}%
                    </td>
                    <td className="p-3 border">
                      {compound.websites.map((url, i) => (
                        <a
                          key={i}
                          href={url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-500 hover:underline block"
                        >
                          {url}
                        </a>
                      ))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </>
  );
};

export default DrugDataCollection;
