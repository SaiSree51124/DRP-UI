import React from "react";
import { NavLink, Outlet } from "react-router-dom";
import { AppBar, Toolbar, Typography, Box, IconButton } from "@mui/material";
import LoginIcon from "@mui/icons-material/Login"; // Importing the Login icon

const Dashboard = () => {
  return (
    <div className="flex flex-col h-screen">
      {/* Top Navigation Bar */}
      <AppBar
        position="fixed" // Changed to fixed
        sx={{
          background:
            "linear-gradient(90deg, #0124AA 11.66%, #00809E 50.37%, #196C69 75.2%, #041634 100%)",
          zIndex: 1100,
        }}
      >
        <Toolbar sx={{ paddingLeft: "10px !important", paddingRight: "10px !important" }}>
          {/* Left side: Platform Title */}
          <Typography
            variant="div"
            sx={{
              flexGrow: 1,
              fontWeight: 700,
              fontSize: "25px",
              lineHeight: "100%",
              letterSpacing: "0%",
              verticalAlign: "middle",
            }}
          >
           DD Platform
          </Typography>

          {/* Right side: Navbar links */}
          <Box sx={{ display: "flex", gap: 3 }}>
            <NavLink
              to="/dashboard/TxKG-knowledge-graph"
              style={({ isActive }) => ({
                color: isActive ? "white" : "#cfd8dc",
                textDecoration: "none",
                fontSize: "14px",
                padding: "8px 16px",
                borderRadius: "4px",
                fontWeight: "500",
              })}
            >
              TxKG
            </NavLink>
            <NavLink
              to="/dashboard/literature-mining"
              style={({ isActive }) => ({
                color: isActive ? "#FFFFFF" : "#cfd8dc",
                textDecoration: "none",
                fontSize: "14px",
                padding: "8px 16px",
                borderRadius: "4px",
                fontWeight: "500",
              })}
            >
              LitMineX
            </NavLink>
            <NavLink
              to="/dashboard/data-curation-engine"
              style={({ isActive }) => ({
                color: isActive ? "white" : "#cfd8dc",
                textDecoration: "none",
                fontSize: "14px",
                padding: "8px 16px",
                borderRadius: "4px",
                fontWeight: "500",
              })}
            >
              CurateX
            </NavLink>
            <NavLink
              to="/dashboard/screening-suite"
              style={({ isActive }) => ({
                color: isActive ? "white" : "#cfd8dc",
                textDecoration: "none",
                fontSize: "14px",
                padding: "8px 16px",
                borderRadius: "4px",
                fontWeight: "500",
              })}
            >
              ScreenSuite
            </NavLink>
            <NavLink
              to="/dashboard/novelty-search-module"
              style={({ isActive }) => ({
                color: isActive ? "white" : "#cfd8dc",
                textDecoration: "none",
                fontSize: "14px",
                padding: "8px 16px",
                borderRadius: "4px",
                fontWeight: "500",
              })}
            >
              NovSearch
            </NavLink>
            <NavLink
              to="/dashboard/aboutus"
              style={({ isActive }) => ({
                color: isActive ? "white" : "#cfd8dc",
                textDecoration: "none",
                fontSize: "14px",
                padding: "8px 16px",
                borderRadius: "4px",
                fontWeight: "500",
              })}
            >
              About Us
            </NavLink>
            
          </Box>

          {/* Rightmost: Login Icon */}
          <IconButton color="inherit" sx={{ marginLeft: 2 }}>
            <img
              src="/authbtn.png" // Replace with your image path
              alt="User Profile"
              style={{ width: 32, height: 32, borderRadius: "50%" }} // Adjust size and make it circular
            />
          </IconButton>
        </Toolbar>
      </AppBar>

      {/* Main Content Area */}
      <Box
        sx={{
          flexGrow: 1,
          p: 2,
          backgroundColor: "#f4f6f8",
          backgroundColor: "#f4f6f8",
          overflowY: "auto", // Enables vertical scrolling
          marginTop: "64px", // Adjusts for AppBar height
          height: "calc(100vh - 64px)",
        }}
      >
        {/* Outlet to render the corresponding route content */}
        <Outlet />
      </Box>
    </div>
  );
};

export default Dashboard;
